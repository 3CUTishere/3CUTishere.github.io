let c = prompt("Input Your Name : ");
let d = confirm(`Nama Anda : ${c}`);
let e = prompt("Apakah sudah benar ? (Yes/No) : ");
if(e === 'Yes'){
    alert("Warning You will Die Today");
} else if(e==='No') {
    alert("I'm Gonna kill Your Mom");
} else {
    
}
